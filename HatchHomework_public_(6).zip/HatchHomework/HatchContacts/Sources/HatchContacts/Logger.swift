//
//  Logger.swift
//
//  Created by hatch.co
//

import os.log

public let logger = os.Logger(
    subsystem: "co.hatch.homework",
    category: "HatchHomework"
)
